#!/bin/bash

echo 'post generation hook';
touch 'shell_pre.txt'
