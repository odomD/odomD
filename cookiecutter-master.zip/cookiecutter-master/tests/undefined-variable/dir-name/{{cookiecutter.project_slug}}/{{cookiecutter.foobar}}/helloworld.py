"""
Sample Python file.

Expected not to be created in a test due to the undefined variable
``cookiecutter.foobar``.
"""
