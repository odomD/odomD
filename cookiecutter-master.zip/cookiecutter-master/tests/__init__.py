"""Cookiecutter integration tests."""
