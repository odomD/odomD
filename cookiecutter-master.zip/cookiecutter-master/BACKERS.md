# Backers

We would like to thank the following people for supporting us in our efforts to maintain and improve Cookiecutter:

* Alex DeBrie
* Alexandre Y. Harano
* Bruno Alla
* Carol Willing
* Russell Keith-Magee
